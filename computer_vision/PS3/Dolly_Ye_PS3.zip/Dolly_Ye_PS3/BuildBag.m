function BagofWords = BuildBag(range1,fnames)
    load('kMeans.mat');
    BagofWords = zeros(300,1500);
    for i = range1
        fname = ['./sift/' fnames(i).name];
        load(fname, 'descriptors');


        [~,inds] = min(dist2(res, descriptors));

        for k = 1:1500
            BagofWords(i,k) = numel(find(inds== k));
            BagofWords(i,:) = BagofWords(i,:)/norm(BagofWords(i,:));
        end 
       
    end
    
end
