clc;
fnames = dir(['./sift/' '/*.mat']);
load('kMeans.mat');
len_fnames = length(fnames);
b = 1;
%two ranges around the two query image
range1 = randperm(len_fnames, 300);
sumfc = BuildFC(fnames);
disp(size(sumfc));
% BagofWords = BuildBag(range1, fnames);


img1 =  "./frames/friends_0000004503.jpeg";
img2 =  "./frames/friends_0000000394.jpeg";

imgs = [ "./sift/friends_0000004503.jpeg.mat"; "./sift/friends_0000000394.jpeg.mat"];
for i = 1:2
    load(imgs(i), 'imname', 'descriptors');
    
    [~,x] = min(dist2(res, descriptors));
    bag = histc(x, 1:1500); 
    bag = bag/norm(bag);

    distance = dist2(bag, BagofWords);
    
    [~, index] = sort(distance); 
    figure;
    img = imread(['./frames/',imname]);
    subplot(6,2,1);
    imshow(img);
    title('SIFT Query Image');
    b =  b+ 1;
    tmp =  range1(index(1:11));
    for j = 2:11
        fname = ['./sift/' fnames(tmp(j)).name];
        load(fname, 'imname', 'descriptors');
        img = imread(['./frames/',imname]);
        subplot(6,2,j);
        imshow(img);
         t = ['SIFT Match Rank ' int2str(j-1)];
        title(t);

    end
    
end

load("./sift/friends_0000000394.jpeg.mat", 'imname', 'deepFC7');

distance1 = dist2(sumfc, deepFC7);

[~, index1] = sort(distance1); 
disp(index1);
figure;
img = imread(['./frames/',imname]);
subplot(6,2,1);
imshow(img);
title('DeepFC Query Image');
b =  b+ 1;
range2 = 500:3200;
tmp1 =  range2(index1(1:11));
for j = 2:11
    fname = ['./sift/' fnames(tmp1(j)).name];
    load(fname, 'imname');
    img = imread(['./frames/',imname]);
    subplot(6,2,j);
    imshow(img);
     t = ['DeepFC Match Rank ' int2str(j-1)];
    title(t);

end



load( "./sift/friends_0000004503.jpeg.mat", 'imname', 'deepFC7');

distance1 = dist2(sumfc, deepFC7);

[~, index1] = sort(distance1); 
disp(index1);
figure;
img = imread(['./frames/',imname]);
subplot(6,2,1);
imshow(img);
title('DeepFC Query Image');
b =  b+ 1;
range2 = 500:3200;
tmp1 =  range2(index1(1:11));
for j = 2:11
    fname = ['./sift/' fnames(tmp1(j)).name];
    load(fname, 'imname');
    img = imread(['./frames/',imname]);
    subplot(6,2,j);
    imshow(img);
     t = ['DeepFC Match Rank ' int2str(j-1)];
    title(t);

end
