function similarity_score = computer_similarity(BagofWords, randomword,len_fnames)
    similarityScores = zeros(len_fnames, 1);
    fname = ['sift/' fnames(range2(i)).name];
    load(fname, 'imname', 'descriptors');
    for i = 1:len_fnames
        

end

