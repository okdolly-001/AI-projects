function fdescriptors = build_visual_vocab(fnames,len_fnames)
    forients = [];
    fpositions = [];
    fscales = [];
    fdescriptors = [];
    frame_name = cell(len_fnames,1);
    
    for i=1:200
        fname = ['./sift/' fnames(i).name];
        fprintf('reading frame %d of %d\n', i, length(fnames));
        load(fname, 'imname', 'descriptors', 'positions', 'scales', 'orients');
        numfeats = size(descriptors,1);
        
        randindexes = randperm(numfeats);
        randinds = randindexes(1:min([100,numfeats])); 

        fpositions = [fpositions; positions(randinds,:)];
        fscales= [fscales; scales(randinds,:)];
        forients = [forients; orients(randinds,:)];
        fdescriptors = [fdescriptors; descriptors(randinds,:)];
    
    end


end
