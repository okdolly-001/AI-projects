function sumfc = BuildFC(fnames)

%     FC = zeros(700,1500);
    sumfc = [];
    for j = 500:3200
        fname = ['./sift/' fnames(j).name];
        load(fname, 'deepFC7');
        sumfc = [sumfc; deepFC7];
    end
    
    
end
