clc;
fnames = dir(['./sift/' '/*.mat']);
len_fnames = length(fnames);
fdescriptors = build_visual_vocab(fnames,len_fnames);
[membership,means,rms] = kmeansML(1500,fdescriptors');
res = means';
save('kMeans.mat','res');

j = 1;
random_w = randi(1500);
counter = 0;

while j < len_fnames
    if counter == 26
        break;
    end
    tosift = ['./sift/' fnames(j).name];
    load(tosift, 'imname', 'descriptors', 'positions', 'scales', 'orients');
    [~,g] = min(dist2(descriptors,res));
    match = find(g == random_w);
    
    for i = match
        counter = counter + 1;
        if counter == 26
            break;
        end
        img = imread(['./frames/',imname]);
        img = rgb2gray(img);
        patches =  getPatchFromSIFTParameters(positions(i,:), scales(i), orients(i), img);
        subplot(5,5,counter);
        imshow(patches);
    end 
    
end


%
j = 1;
random_w = randi(1500);
counter = 0;

while j < len_fnames
    if counter == 26
        break;
    end
    tosift = ['./sift/' fnames(j).name];
    load(tosift, 'imname', 'descriptors', 'positions', 'scales', 'orients');
    [~,g] = min(dist2(descriptors,res));
    match = find(g == random_w);
    
    for i = match
        counter = counter + 1;
        if counter == 26
            break;
        end
        img = imread(['./frames/',imname]);
        img = rgb2gray(img);
        patches =  getPatchFromSIFTParameters(positions(i,:), scales(i), orients(i), img);
        subplot(5,5,counter);
        imshow(patches);
    end 
    
end
