clc;
fnames = dir(['./sift/' '/*.mat']);
load('kMeans.mat');
len_fnames = length(fnames);
b = 1;
range1 = 1:300;
BagofWords = BuildBag(range1, fnames);
range2 = [4, 79,258];

for i = 1:3
    fname = ['./sift/' fnames(range2(i)).name];
    load(fname, 'imname', 'descriptors');
    
    
    [~,x] = min(dist2(res, descriptors));
    bag = histc(x, 1:1500); 
    bag = bag/norm(bag);

    distance = dist2(bag, BagofWords);
    
    [~, index] = sort(distance); 
    figure;
    img = imread(['./frames/',imname]);
    subplot(3,2,1);
    imshow(img);
    title('Query Image');
    b =  b+ 1;
    tmp =  range1(index(1:6));
    for j = 2:6
        fname = ['./sift/' fnames(tmp(j)).name];
        load(fname, 'imname', 'descriptors');
        img = imread(['./frames/',imname]);
        subplot(3,2,j);
        imshow(img);
         t = ['Match Rank ' int2str(j-1)];
        title(t);

    end
    
end
