clear;
load('twoFrameData.mat');
% Find the Region
oninds = selectRegion(im1, positions1); 

[~,rowinds] = find(dist2(descriptors1(oninds,:), descriptors2)<0.2);


figure;
imshow(im2);
displaySIFTPatches(positions2(rowinds,:), scales2(rowinds), orients2(rowinds), im2); 
